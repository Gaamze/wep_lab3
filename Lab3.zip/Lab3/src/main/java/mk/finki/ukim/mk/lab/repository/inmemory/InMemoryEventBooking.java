package mk.finki.ukim.mk.lab.repository.inmemory;

public class InMemoryEventBooking {
}
